# 🎯 Catch Me If You Can

A simple browser game made with **HTML, CSS, and JavaScript**.

## 🎮 How to Play

1. Click **Start Game**.
2. Try to click the red button.
3. The button moves when your mouse gets close.
4. Every successful click gives you a point.
5. You have **20 seconds** to get as many hits as possible.

## 🛠️ Technologies Used

- HTML5
- CSS3
- JavaScript
- Google Fonts

## 📁 Project Structure

```text
catch-me-if-you-can/
├── index.html
├── style.css
├── script.js
└── README.md
```

## ▶️ Run Locally

Download or clone the repository, then open `index.html` in a web browser.

No server or installation is required.

## 🌐 GitHub Pages

This project can be hosted using GitHub Pages because it is a static website.

After uploading the files to GitHub:

1. Open the repository's **Settings**.
2. Go to **Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose the `main` branch and `/ (root)`.
5. Save the settings.
6. GitHub will provide a public website URL.

## 📚 Project Purpose

This project demonstrates basic web development concepts including:

- DOM manipulation
- JavaScript event listeners
- Random number generation
- CSS positioning and styling
- Timers using `setInterval()`
- Responsive web design
